% ----------------------------------------------------------------------
% Different evolution based on game evolution strategy and feature
% selection for global opitimization and real-world challenges (GFDE)
% Author: Pengpeng Shang, Sanyang Liu, Yudong Gong,
% Yiguang Bai, Chunfeng Wang, 2026
% ----------------------------------------------------------------------
function [y,best,bestx,Diver]=GDDE(fhd,D,N,MaxFEs,L,U,fobj)
rand('twister',mod(floor(now*8640000),2^31-1));

X  = Initial(N,D,U,L);
FunVal = feval(fhd,X',fobj);

[g_best,ind] = min(FunVal);
ind    = ind(end);
x_best = X(ind,:);

NP.Chaos = randperm(N,N);
NP.N_SP_1 = 0.5*N;
NP.N_SP_2 = 0.5*N;

NP.SP_1 = NP.Chaos(1:NP.N_SP_1); % Equally divid population into two sub-populations
NP.SP_2 = NP.Chaos(end-NP.N_SP_2+1:end);% Equally divid population into two sub-populations

Fv = randsrc(N,D,[1 0;1 0]); % Initialize the forward matrix
Bv = double(~Fv);            % Initialize the backward vector

alpha = 0.5; % Parameter α
rho   = 0.1; % Parameter ρ
R_N = floor(N/2); % Reset population size

FEs = N;
iter= 1;
y   = [(g_best)*ones(1,N)];
flag = zeros(1,N);  % Initialize record vector
% main loop
while FEs < MaxFEs
    Ins = FEs;
    Temp_1 = 0; Temp_2 = 0;
    Mean_D = mean(X(NP.SP_2,:));  % The mean of SP-2
    [~,pb]  = sort(FunVal,'ascend');
    F = 0.6+0.4*(rand(N,1)-0.5)*((FEs)/MaxFEs)^2; % Adaptive F
    for i=1:N
        [pb_r,r1,r2,r3,r4]=RandNeib(i,N,rho,pb);
        if any(NP.SP_1==i)
            V(i,:)=X(i,:)+F(i)*(X(pb_r,:)-X(i,:)+X(r1,:)-X(r2,:));
        elseif any(NP.SP_2==i)
            V(i,:)=X(r1,:)+F(i).*(X(r2,:)-X(r3,:)+X(r4,:)-Mean_D);
        end
    end
    V = BoundConstraint(V, X, L,U);

    for i=1:N
        %% DCM operation
        if flag(i) == 0      % individual i failed to improve in the previous generation
            [TFv,TBv,U1,U2] = FSC_Fail(V(i,:),X(i,:),alpha,Fv(i,:));
        elseif flag(i) == 1  % individual i successfully improved in the previous generation
            [TFv,TBv,U1,U2] = FSC_Succ(V(i,:),X(i,:),Fv(i,:));
        end
        Temp_FunVal_U1 = feval(fhd,U1',fobj);
        FEs=FEs+1;
        if FEs==MaxFEs
            break
        end
        Temp_FunVal_U2 = feval(fhd,U2',fobj);
        FEs=FEs+1;
        if FEs==MaxFEs
            break
        end
        %% GEP operation
        FunVal_Vertor = [Temp_FunVal_U1,Temp_FunVal_U2,FunVal(i)];
        [~,Number]=min(FunVal_Vertor);%
        if Number==1
            X(i,:) = U1;
            FunVal(i) = Temp_FunVal_U1;
            Fv(i,:) = TFv;
            Bv(i,:) = TBv;
            flag(i) = 1;
            if any(NP.SP_1==i)
                Temp_1=Temp_1+1;
            elseif any(NP.SP_2==i)
                Temp_2=Temp_2+1;
            end
        elseif Number==2
            X(i,:)  = U2;
            FunVal(i) = Temp_FunVal_U2;
            Fv(i,:) = TBv;
            Bv(i,:) = TFv;
            flag(i) = 1;
            if any(NP.SP_1==i)
                Temp_1=Temp_1+1;
            elseif any(NP.SP_2==i)
                Temp_2=Temp_2+1;
            end
        elseif Number==3
            Fv(i,:) = TFv;
            Bv(i,:) = TBv;
            flag(i) = 0;
        end
        % Randomly generated Fv vertor
        if sum(Fv(i,:))==0
            d1 = randi(D,D,1);
            Fv(i,d1) = 1;
            Bv(i,:) = double(~Fv(i,:));
        end
    end

    %% Migration operation
    Len_1 = length(NP.SP_1);
    Len_2 = length(NP.SP_2);
    if  Len_1 > 0 && Len_2 > 0
        ER1 = Temp_1/(Len_1);
        ER2 = Temp_2/(Len_2);
        Delta = -abs(ER1-ER2);
        f_A = 1+(ER1*(Len_1-1)+Delta*(N-Len_1))/(N-1);
        f_B = 1+(Delta*(Len_1)+ER2*(N-Len_1-1))/(N-1);
        if f_A > f_B && Len_2 > 1 && rand<ER1 % SP-1 is superior to SP-2
            Index_2 = randperm(Len_2,1);
            NP.SP_1=[NP.SP_1,NP.SP_2(Index_2)];
            NP.SP_2(Index_2)=[];
        elseif f_B > f_A && Len_1 > 1 && rand<ER2
            Index_1 = randperm(Len_1,1);
            NP.SP_2=[NP.SP_2,NP.SP_1(Index_1)];
            NP.SP_1(Index_1)=[];
        end
    end
    %% Reset operation
    if mod(iter,N/2)==0
        if FEs<MaxFEs&&length(NP.SP_1) < 2
            for j=NP.SP_1
                X(j,:) = L+(U-L)*rand(1,D);
                FunVal(j) = feval(fhd,X(j,:)',fobj);
                FEs = FEs+1;
                if FEs>=MaxFEs
                    break;
                end
            end
            if length(NP.SP_2) >= R_N
                Index_22 = randperm(length(NP.SP_2), min(R_N, length(NP.SP_2)));
                NP.SP_1 = [NP.SP_1, NP.SP_2(Index_22)];
                NP.SP_2(Index_22) = [];
            end
        elseif FEs<MaxFEs&&length(NP.SP_2) < 2
            for j=NP.SP_2
                X(j,:) = L+(U-L)*rand(1,D);
                FunVal(j) = feval(fhd,X(j,:)',fobj);
                FEs = FEs+1;
                if FEs>=MaxFEs
                    break;
                end
            end
            if length(NP.SP_1) >= R_N
                Index_11 = randperm(length(NP.SP_1), min(R_N, length(NP.SP_1)));
                NP.SP_2 = [NP.SP_2, NP.SP_1(Index_11)];
                NP.SP_1(Index_11) = [];
            end
        end
    end
    %% Update optimal value
    ind=find(FunVal==min(FunVal));
    ind=ind(end);
    if FunVal(ind) < g_best
        x_best = X(ind,:);
        g_best = FunVal(ind);
    end
    %% Store results
    y=[y,(g_best)*ones(1,FEs-Ins)];

    disp(['********************************************']);
    disp(['Current FEs = ',num2str(FEs),';  ','Current optimal = ',num2str(g_best)]);
    
    iter=iter+1;
end
best = g_best;
bestx= x_best;
end
%% Randomly neighbors
function [pb_r,r1,r2,r3,r4]=RandNeib(i,N,rho,pb)
pb_r=pb(randperm(ceil(rho*N),1)); % Select the top rho * N elite individuals
while (pb_r==i)
    pb_r=pb(randperm(ceil(rho*N),1));
end
% 选择三个不同的随机个体
idxs = randperm(N, 4);
while any(idxs == i)
    idxs = randperm(N, 4);
end
r1 = idxs(1); r2 = idxs(2); r3 = idxs(3); r4 = idxs(4);
end

%% flag = 1
function [tm_Fv,tm_Bv,U1,U2] = FSC_Succ(tm_v,tm_x,Fv)
rand('twister',mod(floor(now*8640000),2^31-1));

%% Upadate operation
Bv = double(~Fv);
tm_Fv = Fv;
tm_Bv = Bv;

U1 = tm_Fv.*tm_v+tm_Bv.*tm_x;
U2 = tm_Bv.*tm_v+tm_Fv.*tm_x;
end

%% flag = 0
function [tm_Fv,tm_Bv,U1,U2] = FSC_Fail(tm_v,tm_x,alpha,Fv)
rand('twister',mod(floor(now*8640000),2^31-1));

%% Selection operation
index.pop = find(Fv==1);
index.num1= sum(Fv);
index.num2= ceil(alpha*index.num1);
d = index.pop(randperm(index.num1,index.num2));
Fv(d)= 0;
Bv   = double(~Fv);
tm_Fv = Fv;
tm_Bv = Bv;

%% Upadate operation
U1 = tm_Fv.*tm_v+tm_Bv.*tm_x;
U2 = tm_Bv.*tm_v+tm_Fv.*tm_x;
end