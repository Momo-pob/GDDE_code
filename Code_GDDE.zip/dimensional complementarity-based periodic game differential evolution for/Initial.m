% Initialize population
function Pop = Initial(N,D,U,L)
Boundary_no = size(U,2); 
% U, L are real numbers rather than vectors
if Boundary_no == 1  
    Pop = rand(N,D).*(U-L)+L;
end

% U, L are vectors with unequal elements
if Boundary_no>1
    for i=1:D
        Pop(:,i)=rand(N,1).*(U(i)-L(i))+L(i);
    end
end