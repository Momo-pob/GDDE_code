function vi = BoundConstraint(vi, pop, l, u)
% if the boundary constraint is violated, set the value to be the middle
% of the previous value and the bound
[NP, D] = size(pop);  % the population size and the problem's dimension
lu=[l*ones(1,D);u*ones(1,D)];
%% check the lower bound
xl = repmat(lu(1, :), NP, 1);
xu = repmat(lu(2, :), NP, 1);
pos = vi < xl;
% vi(pos) = (pop(pos) + xl(pos)) / 2;
vi(pos) = min(xu(pos) ,2*xl(pos) -vi(pos));

%% check the upper bound
pos = vi > xu;
% vi(pos) = (pop(pos) + xu(pos)) / 2;
vi(pos) = max(xl(pos) ,2*xu(pos) -vi(pos));
end