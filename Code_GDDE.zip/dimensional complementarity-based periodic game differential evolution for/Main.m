clc
clear
close all
format short
fhd= str2func('cec17_func');
N  = 100;
UB = 100; LB = -UB;
D  = 30;
disp(['Dimension = ',num2str(D)]);
runtimes= 1;
MaxFEs  = 10000*D;
for func_num = [1:30]
    disp(['Function = ',num2str(func_num)]);
    for runs=1:runtimes
        %% Search the best results using GFDE
        tic
        [BestFval,GBest,XBest]=GDDE(fhd,D,N,MaxFEs,LB,UB,func_num);
        time=toc;
        %% Calculate the results
        Recor_BF(runs,:) = BestFval;
        Recor_GB(func_num,runs) = GBest;
        Recor_XB(runs,:) = XBest;
        T(func_num,runs) = time;
        disp(['————————————————']);
        disp(['runtimes = ',num2str(runs),';  ','Gloabl Best = ',num2str(GBest),';']);
        disp(['————————————————']);
    end
    %% Storage the results
    Optim_Results.Mean_GB(1,func_num)= mean(Recor_GB(func_num,:));
    Optim_Results.Std_GB(1,func_num) = std(Recor_GB(func_num,:));
    [Optim_Results.Min_GB(1,func_num),xh1] = min(Recor_GB(func_num,:));
    Optim_Results.Min_XB(func_num,:)= Recor_XB(xh1,:);
    Optim_Results.Final_Y(func_num) = {Recor_BF(xh1,:)};
    Optim_Results.Mean_T(1,func_num)= mean(T(func_num,:));
end
