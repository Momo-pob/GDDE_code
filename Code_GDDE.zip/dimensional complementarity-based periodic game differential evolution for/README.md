## GDDE-optimization-algorithm



This is an introduction to the program Matlab code about GDDE



Main: The main program that runs

BoundConstraint：Population upper and lower bound processing program

Initial: Population initialization program

GDDE: A dimensional complementarity-based periodic game differential evolution 

&nbsp;		for numerical optimization and real-world challenges

cec17func: CEC2017 benchmark test suite



Modify the funcnum of Main to switch function calculations

Simply modifying other parameters of Main can achieve the desired function

